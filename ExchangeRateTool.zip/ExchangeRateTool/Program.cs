﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security;
using System.Xml;
using System.Xml.Linq;

namespace ExchangeRateTool
{
  internal class Program
  {
    private const string dateInputFormatString = "yyyyMMdd";
    private const string dateParameterFormatString = "dd.MM.yyyy";
    private const string dateOutputFormatString = "yyyy/MM/dd";
    private const string dateFilenameFormatString = "yyyyMMdd";
    private const string dateCzechFileFormatString = "dd.MMM yyyy";
    private const string dateRussianFileFormatString = "dd.MM.yyyy";
    private const string datePolishFileFormatString = "yyyy-MM-dd";
    private const string exchangeRateNumberFormatString = "0.########";

    private static void Main(string[] args)
    {
      bool consoleOutput;
      string currencyParameter;
      string dateParameter;
      
      // if there is no console input (args), then jump to InteractiveInput method (menu for user input)
      if (args.Length == 0)
      {
        consoleOutput = false;
        Program.InteractiveInput(out currencyParameter, out dateParameter);
      }

      // if there are arguments but the PArseArguments method fails with them, the returns an error message
      else if (!Program.ParseArguments(args, out consoleOutput, out currencyParameter, out dateParameter))
      {
        Console.WriteLine("Invalid parameters.");
        return;
      }

      // declares the outputfilename and stringList that will contain the output data
      string outputFilename = "";
      List<string> stringList;

      // cascading if used to trigger either country's method which returns a stringList with rates from respective national bank websites
      if (!(currencyParameter == "czk"))
      {
        if (!(currencyParameter == "rub"))
        {
          if (!(currencyParameter == "pln"))
          {
            if (!(currencyParameter == "plnA"))
            {
              if (currencyParameter == "plnB")
              {
                stringList = Program.PolishExchangeRate(false, !consoleOutput, out outputFilename);
              }
              else
              {
                Console.WriteLine("Invalid currency parameter.");
                return;
              }
            }
            else
              stringList = Program.PolishExchangeRate(true, !consoleOutput, out outputFilename);
          }
          else
          {
            stringList = Program.PolishExchangeRate(true, !consoleOutput, out outputFilename);
            stringList.AddRange((IEnumerable<string>) Program.PolishExchangeRate(false, !consoleOutput));
          }
        }
        else
          stringList = Program.RussianExchangeRate(!consoleOutput, out outputFilename);
      }
      else
        stringList = Program.CzechExchangeRate(dateParameter, !consoleOutput, out outputFilename);

      // if the Strinlist is null the writes error message
      if (stringList == null)
      {
        Console.WriteLine("Error.");
      }
      else
      {
        // creates the output directory if it doesn't already exist
        if (!Directory.Exists("./output/"))
          Directory.CreateDirectory("./output/");

        // creates the output text file that will contain the rates
        using (TextWriter textWriter = consoleOutput ? Console.Out : (TextWriter) new StreamWriter("./output/" + outputFilename, false))
        {
          // writing each line of the stringList returned by country specific methods in the output file
          foreach (string str in stringList)
            textWriter.WriteLine(str);
        }
        if (consoleOutput)
          return;
        Console.WriteLine("Done!");
      }
    }
   

    // Main method ends here, following methods are called within Main

    // PArseARgument verifies that the arguments passed as input int eh console are in the right format and order
    // returns a boolean true/false if it successes/fails
    private static bool ParseArguments(string[] args, out bool consoleOutput, out string currencyParameter, out string dateParameter)
    {
      consoleOutput = false;
      currencyParameter = (string) null;
      dateParameter = (string) null;
      switch (args.Length)
      {
        case 1:
          consoleOutput = false;
          currencyParameter = args[0];
          dateParameter = "";
          break;
        case 2:
          if (args[0] == "-c")
          {
            consoleOutput = true;
            currencyParameter = args[1];
            dateParameter = "";
            break;
          }
          consoleOutput = false;
          currencyParameter = args[0];
          DateTime result1;

          // if the date is in wrong format or the year is below 2010, then returns false
          if (!DateTime.TryParseExact(args[1], "yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out result1) || result1.Year < 2010)
            return false;
          // if the date is correct, then builds the dateParameter and breaks the Switch
          dateParameter = "?date=" + result1.ToString("dd.MM.yyyy", (IFormatProvider) CultureInfo.InvariantCulture);
          break;
        case 3:
          if (args[0] != "-c")
            return false;
          consoleOutput = true;
          currencyParameter = args[1];
          DateTime result2;
          if (!DateTime.TryParseExact(args[2], "yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out result2) || result2.Year < 2010)
            return false;
          dateParameter = "?date=" + result2.ToString("dd.MM.yyyy", (IFormatProvider) CultureInfo.InvariantCulture);
          break;
        default:
          return false;
      }
      
      // if there was no error in the parsing tasks, then returns true
      return true;
    }

    
    // InteractiveInput is the user menu on the console, taking validated currency and date parameters
    private static void InteractiveInput(out string currencyParameter, out string dateParameter)
    {
      currencyParameter = (string) null;
      dateParameter = (string) null;
      bool flag1 = false;
      bool flag2 = false;
      Console.WriteLine("Enter the currency you're interested in: (czk/pln/plnA/plnB/rub)");

      // if the string entered by user in the console matches one of the listed currency, then assign it to currencyParameter, otherwise error message
      while (!flag1)
      {
        string str = Console.ReadLine();
        if (new List<string>()
        {
          "czk",
          "pln",
          "plnA",
          "plnB",
          "rub"
        }.Contains(str))
        {
          currencyParameter = str;
          flag1 = true;
        }
        else
          Console.WriteLine("Invalid input. Please, answer again. (czk/pln/plnA/plnB/rub)");
      }

      //  treatment for CZK currency

      // check if the currency is matching
      if (!(currencyParameter == "czk"))
        return;

      // if CZK, ask to enter the date
      Console.WriteLine("Enter the date of the exchage rate you're looking for. Leave empty if you want the latest rate. (yyyyMMdd)");
      while (!flag2)
      {
        string s = Console.ReadLine();
        // if the date is empty, download the latest rates
        if (s == "")
        {
          dateParameter = "";
          flag2 = true;
          Console.WriteLine("Fetching the latest rate...");
        }
        // if the date is valid and above 2010, then assign the date entered by user to dateParameter, otherwise error messages
        else
        {
          DateTime result;
          if (!DateTime.TryParseExact(s, "yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out result))
            Console.WriteLine("Invalid input. Please, answer again. (yyyyMMdd)");
          else if (result.Year < 2010)
          {
            Console.WriteLine("Choose a date more recent that 2009. (yyyyMMdd)");
          }
          else
          {
            // formats the dte parameters for the http request
            dateParameter = "?date=" + result.ToString("dd.MM.yyyy", (IFormatProvider) CultureInfo.InvariantCulture);
            flag2 = true;
          }
        }
      }
    }
    
    // CzechExchangeRate returns a list of Czech rates
    private static List<string> CzechExchangeRate(string dateParameter, bool verbose, out string outputFilename)
    {
      List<string> stringList = new List<string>();
      outputFilename = (string) null;
      string str1 = "CZK";
      string str2 = "";
      string str3 = "";
      if (verbose)
        Console.WriteLine("Downloading bank file...");
      
      // creates the query to download the rate file content --> ?date=13.12.2014
      using (WebClient webClient = new WebClient())
      {
        // builds the http request with the bank link and dateParameter
        string address = "http://www.cnb.cz/en/financial_markets/foreign_exchange_market/exchange_rate_fixing/daily.txt" + dateParameter;
        int num = 1;
        try
        {
          // reads the webpage content
          using (Stream stream = webClient.OpenRead(address))
          {
            using (StreamReader streamReader = new StreamReader(stream))
            {
              if (verbose)
                Console.WriteLine("Processing bank file...");
              string str4;

              // reads the content of the file line by line (num is iterator) until the end of the file
              while ((str4 = streamReader.ReadLine()) != null)
              {
                if (num == 1)
                {
                  DateTime result;
                  
                  // parses the first line 0-11 first characters which contains the date in format dd.MM yyyy (ex: 12.Dec 2014)
                  // if it's not working then returns null
                  if (!DateTime.TryParseExact(str4.Substring(0, 11), "dd.MMM yyyy", (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out result))
                    return (List<string>) null;

                  // converts the date format in 2 other formats
                  str2 = result.ToString("yyyy/MM/dd", (IFormatProvider) CultureInfo.InvariantCulture);
                  str3 = result.ToString("yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture);
                }
                if (num > 2)
                {
                  // splits the content of each line of the rate file into a string array 
                  string[] strArray = str4.Split('|');
                  string str5 = strArray[3];
                  
                  // if the currency code is not XDR (IMF special currency), then parses the rate
                  if (!(str5 == "XDR"))
                  {
                    Decimal result1;
                    int result2;
                    
                    // if the parsing of the rate in decimal or the number in integer, then returns null 
                    if (!Decimal.TryParse(strArray[4], NumberStyles.Number, (IFormatProvider) CultureInfo.InvariantCulture, out result1) || !int.TryParse(strArray[2], NumberStyles.None, (IFormatProvider) CultureInfo.InvariantCulture, out result2))
                      return (List<string>) null;

                    // divides the rate by the number (should be 1), then converts it to string and stores it to str6
                    string str6 = (result1 / (Decimal) result2).ToString("0.########", (IFormatProvider) CultureInfo.InvariantCulture);
                    
                    // adding all elements in a string line comma separated in the stringList: str5 (foreign currency code), str1 (domestic currency code), str6 (rate), str2 (date)
                    stringList.Add(str5 + "," + str1 + "," + str6 + "," + str2);
                  }
                  else
                    continue;
                }

                // iterates
                ++num;
              }
            }
          }
        }
        catch (Exception ex) when (ex is WebException || ex is ArgumentNullException)
        {
          return (List<string>) null;
        }
      }
      // defines the name of the output file
      outputFilename = "currency_" + str1 + "_" + str3 + ".txt";
      // returns the stringList
      return stringList;
    }

    private static List<string> RussianExchangeRate(bool verbose, out string outputFilename)
    {
      CultureInfo cultureInfo = new CultureInfo("ru-RU");
      List<string> stringList = new List<string>();
      outputFilename = (string) null;
      if (verbose)
        Console.WriteLine("Downloading bank file...");
      XDocument xdocument;
      try
      {
        xdocument = XDocument.Load("http://www.cbr.ru/scripts/XML_daily_eng.asp");
      }
      catch (Exception ex) when (ex is XmlException || ex is ArgumentNullException || ex is InvalidOperationException || ex is SecurityException)
      {
        return (List<string>) null;
      }
      if (verbose)
        Console.WriteLine("Processing bank file...");
      XElement xelement = xdocument.Element((XName) "ValCurs");
      DateTime result1;
      if (!DateTime.TryParseExact(xelement.Attribute((XName) "Date").Value, "dd.MM.yyyy", (IFormatProvider) cultureInfo, DateTimeStyles.None, out result1))
        return (List<string>) null;
      string str1 = result1.ToString("yyyy/MM/dd", (IFormatProvider) CultureInfo.InvariantCulture);
      string str2 = result1.ToString("yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture);
      string str3 = "RUB";
      foreach (XElement element in xelement.Elements())
      {
        string str4 = element.Element((XName) "CharCode").Value;
        if (!(str4 == "XDR"))
        {
          Decimal result2;
          int result3;
          if (!Decimal.TryParse(element.Element((XName) "Value").Value, NumberStyles.Number, (IFormatProvider) cultureInfo, out result2) || !int.TryParse(element.Element((XName) "Nominal").Value, NumberStyles.None, (IFormatProvider) cultureInfo, out result3))
            return (List<string>) null;
          string str5 = (result2 / (Decimal) result3).ToString("0.########", (IFormatProvider) CultureInfo.InvariantCulture);
          stringList.Add(str4 + "," + str3 + "," + str5 + "," + str1);
        }
      }
      outputFilename = "currency_" + str3 + "_" + str2 + ".txt";
      return stringList;
    }

    private static List<string> PolishExchangeRate(bool isA, bool verbose, out string outputFilename)
    {
      CultureInfo cultureInfo = new CultureInfo("pl-PL");
      List<string> stringList = new List<string>();
      outputFilename = (string) null;
      if (verbose)
        Console.WriteLine("Downloading bank file...");
      string uri = isA ? "http://www.nbp.pl/kursy/xml/LastA.xml" : "http://www.nbp.pl/kursy/xml/LastB.xml";
      XDocument xdocument;
      try
      {
        xdocument = XDocument.Load(uri);
      }
      catch (Exception ex) when (ex is XmlException || ex is ArgumentNullException || ex is InvalidOperationException || ex is SecurityException)
      {
        return (List<string>) null;
      }
      if (verbose)
        Console.WriteLine("Processing bank file...");
      XElement xelement = xdocument.Element((XName) "tabela_kursow");
      DateTime result1;
      if (!DateTime.TryParseExact(xelement.Element((XName) "data_publikacji").Value, "yyyy-MM-dd", (IFormatProvider) cultureInfo, DateTimeStyles.None, out result1))
        return (List<string>) null;
      string str1 = result1.ToString("yyyy/MM/dd", (IFormatProvider) CultureInfo.InvariantCulture);
      string str2 = result1.ToString("yyyyMMdd", (IFormatProvider) CultureInfo.InvariantCulture);
      string str3 = "PLN";
      foreach (XElement element in xelement.Elements((XName) "pozycja"))
      {
        string str4 = element.Element((XName) "kod_waluty").Value;
        if (!(str4 == "XDR"))
        {
          Decimal result2;
          int result3;
          if (!Decimal.TryParse(element.Element((XName) "kurs_sredni").Value, NumberStyles.Number, (IFormatProvider) cultureInfo, out result2) || !int.TryParse(element.Element((XName) "przelicznik").Value, NumberStyles.None, (IFormatProvider) cultureInfo, out result3))
            return (List<string>) null;
          string str5 = (result2 / (Decimal) result3).ToString("0.########", (IFormatProvider) CultureInfo.InvariantCulture);
          stringList.Add(str4 + "," + str3 + "," + str5 + "," + str1);
        }
      }
      outputFilename = "currency_" + str3 + "_" + str2 + ".txt";
      return stringList;
    }

    private static List<string> PolishExchangeRate(bool isA, bool verbose)
    {
      string outputFilename;
      return Program.PolishExchangeRate(isA, verbose, out outputFilename);
    }
  }
}