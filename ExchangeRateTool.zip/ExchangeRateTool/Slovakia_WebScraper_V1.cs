﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;

namespace WebScraper_TaxRates
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Enter a date (yyyyMMdd) : ");
            string dateInput = Console.ReadLine();

            string formattedDate = $"_{dateInput.Substring(6, 2)}.{dateInput.Substring(4, 2)}.{dateInput.Substring(0, 4)}";

            string httpRequest = @"https://www.nbs.sk/en/statistics/exchange-rates/ecb-foreign-exchange-reference-rates/" + formattedDate;

            using (WebClient client = new WebClient())
            {
                string webPageContent = client.DownloadString(httpRequest);

                string patCurrencyCode = "> [A-Z]{3}<";

                MatchCollection matches = Regex.Matches(webPageContent, patCurrencyCode);

                List<string> currencyCodesList = new List<string>();

                foreach (Match match in matches)
                {
                    currencyCodesList.Add(match.ToString().Substring(2, 3));
                }

                string patCurrencyRate = "\\\"white-space:nowrap\\\">\\n{0,1}\\s*([0-9]{1,4},{0,1}[0-9]{0,4}\\.[0-9]{1,6}){0,1}";

                matches = Regex.Matches(webPageContent, patCurrencyRate);

                List<string> currencyRatesList = new List<string>();

                foreach (Match match in matches)
                {
                    currencyRatesList.Add(match.Groups[1].Value.ToString());
                }

                Console.WriteLine("");
               
                
                for (int i = 0; i < currencyCodesList.Count; i++)
                {
                    if (String.IsNullOrWhiteSpace(currencyRatesList[i]))
                    {
                        continue;
                    }
                    Console.WriteLine($"{currencyCodesList[i]} - {currencyRatesList[i]}");
                }
                
             
                Console.ReadKey();
            }
        }
    }
}
