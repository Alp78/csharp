﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExchangeRateTool")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SAP SE")]
[assembly: AssemblyProduct("ExchangeRateTool")]
[assembly: AssemblyCopyright("Copyright © SAP SE 2017")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("ea52a817-095b-4d17-92a6-6ba2019573f9")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
